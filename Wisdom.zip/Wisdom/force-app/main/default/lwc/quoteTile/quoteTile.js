import { LightningElement } from 'lwc';

export default class QuoteTile extends LightningElement {

    imgData = {

        'Quote_pic__c':'/resource/quotetopics/topics/women/Q20.jpg',

        'AuthorName': 'B. R. Ambedkar'

    }

}